// import { createSlice } from "@reduxjs/toolkit";


// const UserData= createSlice({
//     name: 'UserData',
//     initialState: {
//         qty: JSON.parse(localStorage.getItem("Qty", "0")), //number example
//         name: "", // string example
//         usernames: [] //array of obj example
//     },
//     reducers:{
//         qtyItem(state,action){
//             state.qty = action.payload
//             localStorage.setItem("Qty",action.payload)
//         },
//         NameOfItems(state,action){
//             state.name=action.payload
//         },  
//         usernames(state,action){
//             state.usernames=action.payload
//         }
//     }
// })


// export default UserData.reducer;
// export const {qtyItem,NameOfItems,usernames}=UserData.actions;