import React from 'react'

const index = () => {
  return (
    <div>About nested</div>
  )
}

export default index