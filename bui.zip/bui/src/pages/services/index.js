import React from 'react'

const service = () => {
  return (
    <div>service</div>
  )
}

export default service