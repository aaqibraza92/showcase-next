
import React from 'react'

const allService = (props) => {

  return (
    <div>allService</div>
  )
}

export default allService