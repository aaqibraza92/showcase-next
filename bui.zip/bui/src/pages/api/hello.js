

const handler = async (req,res) => {
  // const {data}= await axios.get(`${megaMenu}`)
  // const dataJson = await data.json()
  // console.log("dataJsonInner",dataJson)
        
      }

      export default handler