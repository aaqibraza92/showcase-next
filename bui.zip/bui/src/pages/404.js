import React from 'react'

const FourZeroFour = () => {
  return (
    <div>FourZeroFour</div>
  )
}

export default FourZeroFour