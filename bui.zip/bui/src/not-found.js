import React from 'react'

const NotFound = () => {
  return (
    <div>Page is not found</div>
  )
}

export default NotFound